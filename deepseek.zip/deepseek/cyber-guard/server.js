const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const pool = require('./server/server/config/db.js');
const config = require('./config/auth_codes');

const app = express();

// 中间件
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // 生产环境应设为true并启用HTTPS
}));

// 静态文件服务
app.use(express.static(path.join(__dirname)));

// 路由
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'auth', 'login-register.html'));
});

// 登录路由
app.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    // 查询数据库
    const [rows] = await pool.query(
      'SELECT * FROM admins WHERE username = ?', 
      [username]
    );
    
    if (rows.length === 0) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    
    const admin = rows[0];
    
    // 验证密码
    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    
    // 设置会话
    req.session.adminId = admin.id;
    req.session.isLoggedIn = true;
    
    res.json({ success: true, redirect: '/admin/dashboard' });
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 注册路由
app.post('/auth/register', async (req, res) => {
  try {
    const { authCode, username, email, password, confirmPassword } = req.body;
    
    // 验证授权码
    if (authCode !== config.registrationAuthCode) {
      return res.status(403).json({ error: '无效的授权码' });
    }
    
    // 验证密码匹配
    if (password !== confirmPassword) {
      return res.status(400).json({ error: '密码不匹配' });
    }
    
    // 检查用户名是否已存在
    const [existing] = await pool.query(
      'SELECT id FROM admins WHERE username = ? OR email = ?',
      [username, email]
    );
    
    if (existing.length > 0) {
      return res.status(400).json({ error: '用户名或邮箱已存在' });
    }
    
    // 加密密码
    const hashedPassword = await bcrypt.hash(password, 12);
    
    // 创建新管理员
    await pool.query(
      'INSERT INTO admins (username, email, password) VALUES (?, ?, ?)',
      [username, email, hashedPassword]
    );
    
    res.json({ success: true, message: '注册成功，请登录' });
  } catch (error) {
    console.error('注册错误:', error);
    res.status(500).json({ error: '服务器错误' });
  }
});

// 检查登录状态
app.get('/auth/check', (req, res) => {
  res.json({ isLoggedIn: !!req.session.isLoggedIn });
});

// 登出路由
app.get('/auth/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});