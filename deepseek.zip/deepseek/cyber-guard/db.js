const initSqlJs = require('sql.js/dist/sql-wasm.js').default;
const fs = require('fs').promises;
const path = require('path');

// 连接到本地SQLite数据库文件
async function connectDatabase() {
    try {
        const SQL = await initSqlJs({
            locateFile: file => path.resolve(__dirname, 'node_modules', 'sql.js', 'dist', file)
        });
        const dbPath = path.resolve(__dirname, 'instance', 'database.db');
        const fileBuffer = await fs.readFile(dbPath).catch(() => null);
        const db = new SQL.Database(fileBuffer || undefined);

        // 为sql.js添加Promise支持的查询方法
        db.get = (sql, params = []) => {
            return new Promise((resolve, reject) => {
                try {
                    const stmt = db.prepare(sql);
                    const result = stmt.get(params);
                    stmt.free();
                    resolve(result);
                } catch (err) {
                    reject(err);
                }
            });
        };

        db.all = (sql, params = []) => {
            return new Promise((resolve, reject) => {
                try {
                    const stmt = db.prepare(sql);
                    const result = stmt.all(params);
                    stmt.free();
                    resolve(result);
                } catch (err) {
                    reject(err);
                }
            });
        };

        console.log('成功连接到本地SQLite数据库 (sql.js)');
        return db;
    } catch (err) {
        console.error('数据库连接错误:', err.message);
        throw err;
    }
}

// 导出数据库实例
module.exports = connectDatabase();