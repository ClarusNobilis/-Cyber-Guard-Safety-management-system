-- 创建admins表
DROP TABLE IF EXISTS admins;
CREATE TABLE admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 可选：插入测试管理员 (密码: admin123)
INSERT INTO admins (username,  password) VALUES (
    'admin',
    '$2a$12$YQvJPUaH3f2N6KYlQ5B8e.3JzW9hN7qyV8xKj2LmP1nGtFvZwXbO6' -- bcrypt hash of 'admin123'
);