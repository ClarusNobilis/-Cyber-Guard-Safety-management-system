module.exports = {
  registrationAuthCode: 'fUQ1-TRia-2oBu-MqZI'
};