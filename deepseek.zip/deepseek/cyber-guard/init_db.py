import sqlite3
import os

# 获取数据库路径
db_path = os.path.join(os.path.dirname(__file__), 'instance', 'database.db')

# 读取SQL文件内容
with open('create_table.sql', 'r', encoding='utf-8') as f:
    sql_content = f.read()

# 连接数据库并执行SQL
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    cursor.executescript(sql_content)
    conn.commit()
    print('数据库表创建成功')
except Exception as e:
    print(f'创建表时出错: {e}')
    conn.rollback()
finally:
    conn.close()