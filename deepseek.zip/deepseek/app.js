const express = require('express');
const bodyParser = require('body-parser');
const { createLogger, format, transports } = require('winston');

// 配置详细日志
const logger = createLogger({
  level: 'debug',
  format: format.combine(
    format.timestamp(),
    format.json()
  ),
  transports: [new transports.Console()]
});
const cors = require('cors');
const authRoutes = require('./authRoutes');
const path = require('path');

// 创建Express应用
const app = express();

// 基本配置
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS || '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE']
}));

// 请求体解析 - 增强调试功能
app.use(bodyParser.json({
  strict: false,
  limit: '10mb',
  verify: (req, res, buf, encoding) => {
    logger.debug('Received raw body:', buf.toString());
  }
}));
app.use(bodyParser.urlencoded({ 
  extended: true,
  verify: (req, res, buf, encoding) => {
    logger.debug('Received urlencoded body:', buf.toString());
  }
}));

// 请求日志中间件
app.use((req, res, next) => {
  logger.debug(`Incoming ${req.method} request to ${req.path}`, {
    headers: req.headers,
    query: req.query,
    body: req.body
  });
  next();
});

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));

// 注册路由
app.use('/api', authRoutes);

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        error: '服务器内部错误',
        message: err.message
    });
});

// 404处理
app.use((req, res) => {
    res.status(404).json({
        error: '端点不存在',
        path: req.path
    });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
    console.log('管理员注册端点: POST /api/register/admin');
    console.log('授权码刷新端点: POST /api/auth/refresh-code');
});

// 热重载支持
if (process.env.NODE_ENV === 'development') {
    process.on('SIGUSR2', () => {
        process.exit(0);
    });
}