/**
 * 认证管理模块
 * 处理用户登录、注册、登出和会话状态管理
 */
const Auth = {
    /**
     * 检查用户是否已登录
     * @returns {boolean} 用户登录状态
     */
    isLoggedIn() {
        return localStorage.getItem('user') !== null;
    },

    /**
     * 获取当前登录用户信息
     * @returns {Object|null} 用户信息对象或null（如果未登录）
     */
    getCurrentUser() {
        const userStr = localStorage.getItem('user');
        return userStr ? JSON.parse(userStr) : null;
    },

    /**
     * 用户登录
     * @param {string} username 用户名或邮箱
     * @param {string} password 密码
     * @returns {Promise} 登录结果Promise
     */
    login(username, password) {
        // 实际项目中这里应该调用后端API
        // 这里使用模拟数据演示
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // 模拟登录成功
                const user = {
                    id: 1,
                    username: username,
                    name: username,
                    email: `${username}@example.com`,
                    role: 'user'
                };
                
                // 存储用户信息到localStorage
                localStorage.setItem('user', JSON.stringify(user));
                
                // 更新UI
                this.updateAuthUI();
                
                resolve(user);
            }, 500);
        });
    },

    /**
     * 管理员登录
     * @param {string} username 管理员账号
     * @param {string} password 密码
     * @param {string} code 验证码
     * @returns {Promise} 登录结果Promise
     */
    adminLogin(username, password, code) {
        // 实际项目中这里应该调用后端API
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // 模拟登录成功
                const user = {
                    id: 100,
                    username: username,
                    name: username,
                    email: `${username}@cyberguard.com`,
                    role: 'admin'
                };
                
                // 存储用户信息到localStorage
                localStorage.setItem('user', JSON.stringify(user));
                
                // 更新UI
                this.updateAuthUI();
                
                resolve(user);
            }, 500);
        });
    },

    /**
     * 用户注册
     * @param {string} username 用户名
     * @param {string} email 邮箱
     * @param {string} password 密码
     * @returns {Promise} 注册结果Promise
     */
    register(username, email, password) {
        // 实际项目中这里应该调用后端API
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // 模拟注册成功
                const user = {
                    id: Math.floor(Math.random() * 1000) + 2,
                    username: username,
                    name: username,
                    email: email,
                    role: 'user'
                };
                
                // 存储用户信息到localStorage
                localStorage.setItem('user', JSON.stringify(user));
                
                // 更新UI
                this.updateAuthUI();
                
                resolve(user);
            }, 500);
        });
    },

    /**
     * 管理员注册
     * @param {string} username 管理员账号
     * @param {string} email 邮箱
     * @param {string} password 密码
     * @param {string} inviteCode 邀请码
     * @returns {Promise} 注册结果Promise
     */
    adminRegister(username, email, password, inviteCode) {
        // 实际项目中这里应该调用后端API
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // 模拟注册成功
                const user = {
                    id: Math.floor(Math.random() * 100) + 101,
                    username: username,
                    name: username,
                    email: email,
                    role: 'admin'
                };
                
                // 存储用户信息到localStorage
                localStorage.setItem('user', JSON.stringify(user));
                
                // 更新UI
                this.updateAuthUI();
                
                resolve(user);
            }, 500);
        });
    },

    /**
     * 用户登出
     */
    logout() {
        // 清除localStorage中的用户信息
        localStorage.removeItem('user');
        
        // 更新UI
        this.updateAuthUI();
        
        // 如果当前在dashboard页面，则跳转到首页
        if (window.location.pathname.includes('dashboard')) {
            window.location.href = 'index.html';
        }
    },

    /**
     * 更新认证相关UI元素
     */
    updateAuthUI() {
        const authButtons = document.querySelector('.auth-buttons');
        if (!authButtons) return;
        
        if (this.isLoggedIn()) {
            const user = this.getCurrentUser();
            authButtons.innerHTML = `
                <a href="dashboard.html" class="btn btn-outline">控制台</a>
                <a href="#" class="btn btn-primary logout-btn">退出</a>
            `;
            
            // 添加登出按钮事件监听
            const logoutBtn = document.querySelector('.logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.logout();
                });
            }
        } else {
            authButtons.innerHTML = `
                <a href="login.html" class="btn btn-outline">登录</a>
                <a href="login.html" class="btn btn-primary">注册</a>
            `;
        }
    },

    /**
     * 检查认证状态并更新UI
     * 在每个页面加载时调用
     */
    checkAuth() {
        this.updateAuthUI();
    }
};

// 页面加载完成后检查认证状态
document.addEventListener('DOMContentLoaded', function() {
    Auth.checkAuth();
});