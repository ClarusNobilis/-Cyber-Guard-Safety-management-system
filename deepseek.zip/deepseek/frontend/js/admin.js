// 新增实时审计队列
class AuditQueue {
  constructor() {
    this.queue = [];
    this.initWebSocket();
  }

// 实时请求追踪器
class RequestTracer {
  constructor() {
    this.ws = null;
    this.reconnectAttempts = 0;
    this.maxReconnects = 5;
    this.initWebSocket();
  }

  initWebSocket() {
    // 关闭现有连接
    if (this.ws) {
      this.ws.close();
    }

    // 创建新连接
    this.ws = new WebSocket('wss://api.example.com/admin/audit-trail');

    // 连接打开时的处理
    this.ws.onopen = () => {
      console.log('审计追踪WebSocket连接已建立');
      this.reconnectAttempts = 0; // 重置重连计数器
      this.subscribeToEvents();
    };

    // 接收消息时的处理
    this.ws.onmessage = (event) => {
      try {
        const auditData = JSON.parse(event.data);
        this.processAuditEvent(auditData);
      } catch (error) {
        console.error('解析审计数据失败:', error);
      }
    };

    // 连接关闭时的处理
    this.ws.onclose = (event) => {
      console.log(`审计追踪WebSocket连接已关闭: ${event.code}`);
      if (this.reconnectAttempts < this.maxReconnects) {
        setTimeout(() => {
          this.reconnectAttempts++;
          console.log(`尝试重连 (${this.reconnectAttempts}/${this.maxReconnects})...`);
          this.initWebSocket();
        }, 3000 * this.reconnectAttempts); // 指数退避重连
      } else {
        console.error('达到最大重连次数，无法恢复连接');
        this.showConnectionError();
      }
    };

    // 连接错误时的处理
    this.ws.onerror = (error) => {
      console.error('审计追踪WebSocket错误:', error);
    };
  }

  // 订阅审计事件
  subscribeToEvents() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        action: 'subscribe',
        types: ['login_attempt', 'content_modification', 'user_management', 'system_config_change'],
        severity: ['high', 'critical']
      }));
    }
  }

  // 处理审计事件
  processAuditEvent(data) {
    const eventElement = document.createElement('div');
    eventElement.className = `audit-event severity-${data.severity}`;
    eventElement.innerHTML = `
      <div class="event-header">
        <span class="event-type">${this.formatEventType(data.type)}</span>
        <span class="event-time">${new Date(data.timestamp).toLocaleString()}</span>
        <span class="event-severity">${data.severity.toUpperCase()}</span>
      </div>
      <div class="event-details">
        <p><strong>用户:</strong> ${data.user || '未知'}</p>
        <p><strong>操作:</strong> ${data.action}</p>
        <p><strong>IP地址:</strong> ${data.ip_address || '隐藏'}</p>
        ${data.details ? `<p><strong>详情:</strong> ${this.sanitizeHTML(data.details)}</p>` : ''}
      </div>
    `;

    // 添加到审计日志容器
    const auditContainer = document.getElementById('real-time-audit-log');
    if (auditContainer) {
      auditContainer.prepend(eventElement); // 添加到顶部
      // 自动滚动到最新条目
      eventElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      // 限制日志数量，保持性能
      this.limitAuditLogSize(auditContainer, 100);
    }

    // 严重事件添加视觉提醒
    if (data.severity === 'critical') {
      this.triggerCriticalAlert(data);
    }
  }

  // 格式化事件类型
  formatEventType(type) {
    const typeMap = {
      'login_attempt': '登录尝试',
      'content_modification': '内容修改',
      'user_management': '用户管理',
      'system_config_change': '系统配置变更'
    };
    return typeMap[type] || type;
  }

  // 清理HTML以防止XSS
  sanitizeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // 限制审计日志大小
  limitAuditLogSize(container, maxEntries) {
    while (container.children.length > maxEntries) {
      container.removeChild(container.lastChild);
    }
  }

  // 触发严重事件警报
  triggerCriticalAlert(data) {
    // 创建桌面通知（如果权限允许）
    if (Notification && Notification.permission === 'granted') {
      new Notification('严重安全事件', {
        body: `${data.action} - ${data.user || '未知用户'}`,
        icon: '/assets/icons/alert-icon.png'
      });
    }

    // 在页面上显示警报
    const alertElement = document.createElement('div');
    alertElement.className = 'critical-alert';
    alertElement.innerHTML = `
      <i class="fas fa-exclamation-triangle"></i>
      <div class="alert-content">
        <h3>严重安全事件</h3>
        <p>${data.action}</p>
        <small>${new Date(data.timestamp).toLocaleString()}</small>
      </div>
      <button class="dismiss-alert">&times;</button>
    `;
    document.body.appendChild(alertElement);

    // 添加关闭按钮事件
    alertElement.querySelector('.dismiss-alert').addEventListener('click', () => {
      alertElement.remove();
    });

    // 自动关闭警报
    setTimeout(() => {
      alertElement.classList.add('fade-out');
      setTimeout(() => alertElement.remove(), 500);
    }, 10000);
  }

  // 显示连接错误
  showConnectionError() {
    const errorElement = document.createElement('div');
    errorElement.className = 'connection-error';
    errorElement.innerHTML = `
      <i class="fas fa-exclamation-circle"></i>
      <span>审计追踪连接已中断，请刷新页面或联系系统管理员</span>
      <button class="reconnect-btn">重新连接</button>
    `;
    document.getElementById('audit-controls')?.appendChild(errorElement);

    // 添加重新连接按钮事件
    errorElement.querySelector('.reconnect-btn').addEventListener('click', () => {
      errorElement.remove();
      this.reconnectAttempts = 0;
      this.initWebSocket();
    });
  }
}

// 页面加载完成后初始化审计追踪
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('real-time-audit-log')) {
    const requestTracer = new RequestTracer();
    // 暴露到全局以便调试（生产环境可移除）
    window.requestTracer = requestTracer;
  }
});

  initWebSocket() {
    this.ws = new WebSocket('wss://api.example.com/audit-feed');
    
    this.ws.onmessage = (event) => {
      const auditData = JSON.parse(event.data);
      this.queue.push(auditData);
      this.renderQueue();
      
      if (auditData.severity === 'CRITICAL') {
        triggerAuditAlert(auditData);
      }
    };
  }

  renderQueue() {
    const container = document.getElementById('audit-queue');
    container.innerHTML = this.queue
      .map(item => `<div class="audit-item ${item.severity.toLowerCase()}">
        <span>${new Date(item.timestamp).toLocaleTimeString()}</span>
        <code>${item.operation}</code>
        <em>${item.user}</em>
      </div>`)
      .join('');
  }
}

// 待开发实时请求追踪
class RequestTracer {
  constructor() {
    // 需要实现WebSocket实时监控
  }
}