// 工具页面功能脚本
class ToolsManager {
  constructor() {
    // 新增工具分类过滤器
    this.initToolFilters(); 
  }

  initToolFilters() {
    document.querySelectorAll('.tool-filter').forEach(btn => {
      btn.addEventListener('click', () => {
        const category = btn.dataset.category;
        this.filterTools(category);
      });
    });
  }

  filterTools(category) {
    // 实现按类别过滤逻辑
  }
}

// 初始化工具管理器
document.addEventListener('DOMContentLoaded', () => new ToolsManager());

  // 初始化下载统计图表
  async initDownloadStats() {
    const ctx = document.getElementById('download-chart');
    if (!ctx) return;

    // 加载Chart.js库
    if (!window.Chart) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      script.onload = () => this.renderChart(ctx);
      document.head.appendChild(script);
    } else {
      this.renderChart(ctx);
    }
  }

  // 渲染下载趋势图表
  async renderChart(ctx) {
    try {
      // 获取下载数据（实际项目中替换为API请求）
      const downloadData = await this.getDownloadData();

      this.downloadChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: downloadData.months,
          datasets: [{ 
            label: '下载量',
            data: downloadData.counts,
            borderColor: '#00bcd4',
            backgroundColor: 'rgba(0, 188, 212, 0.1)',
            tension: 0.3,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { beginAtZero: true, grid: { color: 'rgba(255, 255, 255, 0.1)' } },
            x: { grid: { display: false } }
          }
        }
      });

      // 更新总下载量
      document.getElementById('total-download-count').textContent =
        downloadData.counts.reduce((a, b) => a + b, 0).toLocaleString();
    } catch (error) {
      console.error('下载统计初始化失败:', error);
    }
  }

  // 获取下载数据（模拟API请求）
  async getDownloadData() {
    // 实际项目中替换为真实API调用
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({
          months: ['1月', '2月', '3月', '4月', '5月', '6月'],
          counts: [120, 190, 300, 500, 450, 600]
        });
      }, 500);
    });
  }

  // 初始化数字签名验证
  initSignatureVerification() {
    const verifyBtn = document.getElementById('verifySignature');
    if (verifyBtn) {
      verifyBtn.addEventListener('click', () => this.verifySignature());
    }
  }

  // 验证数字签名
  async verifySignature() {
    const statusElement = document.createElement('div');
    statusElement.className = 'verification-status verifying';
    statusElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 正在验证签名...';

    const signatureContainer = document.querySelector('.digital-signature');
    signatureContainer.appendChild(statusElement);

    try {
      // 模拟签名验证过程
      await new Promise(resolve => setTimeout(resolve, 1500));

      // 实际项目中替换为真实的PGP验证逻辑
      const isValid = Math.random() > 0.3; // 模拟随机结果

      statusElement.className = `verification-status ${isValid ? 'valid' : 'invalid'}`;
      statusElement.innerHTML = isValid ? 
        '<i class="fas fa-check-circle"></i> 签名验证通过，文件完整' : 
        '<i class="fas fa-exclamation-circle"></i> 签名验证失败，文件可能被篡改';
    } catch (error) {
      statusElement.className = 'verification-status error';
      statusElement.innerHTML = '<i class="fas fa-times-circle"></i> 验证失败：' + error.message;
    }
  }
}

// 初始化工具管理器
document.addEventListener('DOMContentLoaded', () => new ToolsManager());