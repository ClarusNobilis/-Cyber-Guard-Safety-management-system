// 导航栏状态管理
class NavManager {
    constructor() {
        this.authButtons = document.querySelector('.auth-buttons');
        this.init();
    }

    init() {
        // 检查登录状态
        const token = localStorage.getItem('token');
        if (token) {
            this.updateNavForLoggedInUser();
        } else {
            this.updateNavForGuest();
        }

        // 添加退出登录事件监听
        document.addEventListener('click', (e) => {
            if (e.target.matches('.btn-logout')) {
                e.preventDefault();
                this.handleLogout();
            }
        });
    }

    updateNavForLoggedInUser() {
        if (this.authButtons) {
            this.authButtons.innerHTML = `
                <a href="dashboard.html" class="btn btn-outline">控制台</a>
                <a href="#" class="btn btn-primary btn-logout">退出</a>
            `;
        }
    }

    updateNavForGuest() {
        if (this.authButtons) {
            this.authButtons.innerHTML = `
                <a href="login.html" class="btn btn-outline">登录</a>
                <a href="register.html" class="btn btn-primary">注册</a>
            `;
        }
    }

    handleLogout() {
        // 清除token
        localStorage.removeItem('token');
        // 更新导航栏
        this.updateNavForGuest();
        // 如果在需要登录的页面，重定向到登录页
        const protectedPages = ['dashboard.html', 'profile.html'];
        const currentPage = window.location.pathname.split('/').pop();
        if (protectedPages.includes(currentPage)) {
            window.location.href = 'login.html';
        }
    }
}

// 当DOM加载完成后初始化导航栏管理器
document.addEventListener('DOMContentLoaded', () => {
    new NavManager();
});

// 导出NavManager类，以便其他模块可以使用
window.NavManager = NavManager;