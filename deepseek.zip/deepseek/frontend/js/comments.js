// 评论系统功能实现
class CommentSystem {
  constructor() {
    this.commentInput = document.getElementById('comment-input');
    this.submitBtn = document.getElementById('submit-comment');
    this.commentsList = document.getElementById('comments-list');
    this.initEvents();
    this.loadComments();
  }

  // 初始化事件监听
  initEvents() {
    this.submitBtn.addEventListener('click', () => this.submitComment());
    this.commentInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.submitComment();
      }
    });
  }

  // 提交评论
  async submitComment() {
    const content = this.commentInput.value.trim();
    if (!content) {
      alert('请输入评论内容');
      return;
    }

    this.submitBtn.disabled = true;
    this.submitBtn.textContent = '提交中...';

    try {
      // 模拟API请求提交评论
      const response = await fetch('/api/comments', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          content: this.sanitizeHTML(content),
          articleId: this.getArticleId()
        })
      });

      if (response.ok) {
        this.commentInput.value = '';
        this.loadComments(); // 重新加载评论列表
      } else {
        const data = await response.json();
        alert(data.message || '评论提交失败，请重试');
      }
    } catch (error) {
      console.error('评论提交错误:', error);
      alert('网络错误，请稍后重试');
    } finally {
      this.submitBtn.disabled = false;
      this.submitBtn.textContent = '提交评论';
    }
  }

  // 加载评论列表
  async loadComments() {
    try {
      // 模拟API请求获取评论
      const response = await fetch(`/api/articles/${this.getArticleId()}/comments`);
      const comments = await response.json();

      this.renderComments(comments);
    } catch (error) {
      console.error('评论加载错误:', error);
      this.commentsList.innerHTML = '<div class="error-message">评论加载失败</div>';
    }
  }

  // 渲染评论列表
  renderComments(comments) {
    if (comments.length === 0) {
      this.commentsList.innerHTML = '<div class="no-comments">暂无评论，来发表第一条评论吧~</div>';
      return;
    }

    this.commentsList.innerHTML = comments.map(comment => `
      <div class="comment-item">
        <div class="comment-header">
          <span class="comment-author">${this.sanitizeHTML(comment.author)}</span>
          <span class="comment-date">${new Date(comment.date).toLocaleString()}</span>
        </div>
        <div class="comment-content">${this.sanitizeHTML(comment.content)}</div>
        <div class="comment-actions">
          <button class="like-btn" data-id="${comment.id}">
            <i class="fas fa-thumbs-up"></i> ${comment.likes}
          </button>
        </div>
      </div>
    `).join('');

    // 添加点赞事件监听
    document.querySelectorAll('.like-btn').forEach(btn => {
      btn.addEventListener('click', () => this.likeComment(btn.dataset.id, btn));
    });
  }

  // 评论点赞
  async likeComment(commentId, button) {
    try {
      const response = await fetch(`/api/comments/${commentId}/like`, { method: 'POST' });
      if (response.ok) {
        const currentLikes = parseInt(button.textContent.trim());
        button.innerHTML = `<i class="fas fa-thumbs-up"></i> ${currentLikes + 1}`;
        button.disabled = true;
      }
    } catch (error) {
      console.error('评论点赞错误:', error);
    }
  }

  // 获取文章ID（从URL参数或页面元数据中）
  getArticleId() {
    // 实际项目中应从URL或页面元数据获取
    return window.location.pathname.split('/').pop().split('.')[0] || '1';
  }

  // HTML内容净化，防止XSS攻击
  sanitizeHTML(html) {
    const div = document.createElement('div');
    div.textContent = html;
    return div.innerHTML;
  }
}

// 初始化评论系统
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('comments-list')) {
    new CommentSystem();
  }
});
class CommentSystem {
  submitComment() {
    // 增加话题标签解析逻辑
    const topics = this.extractTopics(content);
  }

  extractTopics(content) {
    // 使用正则提取#话题标签
  }
}