class KnowledgeBase {
    constructor() {
        this.initElements();
        this.bindEvents();
        this.loadKnowledgeItems();
    }

    initElements() {
        // 获取DOM元素
        this.categoryCards = document.querySelectorAll('.category-card');
        this.searchInput = document.getElementById('knowledge-search-input');
        this.searchButton = document.querySelector('.search-btn');
        this.sortSelect = document.getElementById('sort-by');
        this.knowledgeList = document.getElementById('knowledge-list');

        // 存储知识条目数据
        this.knowledgeItems = [];
        this.filteredItems = [];
    }

    bindEvents() {
        // 分类卡片点击事件
        this.categoryCards.forEach(card => {
            card.addEventListener('click', () => this.onCategoryClick(card));
        });

        // 搜索事件
        this.searchButton.addEventListener('click', () => this.performSearch());
        this.searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.performSearch();
        });

        // 排序事件
        this.sortSelect.addEventListener('change', () => this.sortKnowledgeItems());
    }

    // 加载知识条目数据
    loadKnowledgeItems() {
        // 模拟API请求加载数据
        this.knowledgeItems = [
            {
                id: 1,
                title: 'Log4j2漏洞深度分析与防御措施',
                excerpt: 'Apache Log4j2远程代码执行漏洞(CVE-2021-44228)是近年来影响最广泛的安全漏洞之一，本文将深入分析漏洞原理、攻击方式及全方位防御策略...',
                category: 'threats',
                categoryName: '威胁情报',
                date: '2023-10-15',
                views: 2403,
                bookmarks: 328,
                comments: 45
            },
            {
                id: 2,
                title: '零信任架构(Zero Trust)实施指南',
                excerpt: '零信任架构不再假设内部网络是安全的，而是采用"永不信任，始终验证"的原则。本文详细介绍零信任模型的核心组件、实施步骤和常见挑战...',
                category: 'defense',
                categoryName: '防御技术',
                date: '2023-09-28',
                views: 1845,
                bookmarks: 256,
                comments: 32
            },
            {
                id: 3,
                title: 'GDPR合规要求与数据保护最佳实践',
                excerpt: '通用数据保护条例(GDPR)对全球企业提出了严格的数据保护要求。本文解读GDPR的核心条款，并提供实用的数据合规策略和实施建议...',
                category: 'compliance',
                categoryName: '合规标准',
                date: '2023-09-10',
                views: 1532,
                bookmarks: 189,
                comments: 27
            },
            {
                id: 4,
                title: 'Burp Suite高级使用技巧与插件推荐',
                excerpt: 'Burp Suite是Web应用安全测试的必备工具，本文分享高级使用技巧、自定义工作流配置以及精选插件，帮助安全测试人员提升工作效率...',
                category: 'tools',
                categoryName: '工具教程',
                date: '2023-08-25',
                views: 3217,
                bookmarks: 412,
                comments: 63
            }
        ];

        this.filteredItems = [...this.knowledgeItems];
        this.renderKnowledgeItems();
    }

    // 分类卡片点击处理
    onCategoryClick(card) {
        // 移除所有卡片的active类
        this.categoryCards.forEach(c => c.classList.remove('active'));
        // 为当前点击的卡片添加active类
        card.classList.add('active');

        const category = card.dataset.category;
        if (category === 'all') {
            this.filteredItems = [...this.knowledgeItems];
        } else {
            this.filteredItems = this.knowledgeItems.filter(item => item.category === category);
        }

        this.renderKnowledgeItems();
    }

    // 执行搜索
    performSearch() {
        const searchTerm = this.searchInput.value.trim().toLowerCase();
        if (!searchTerm) {
            this.filteredItems = [...this.knowledgeItems];
        } else {
            this.filteredItems = this.knowledgeItems.filter(item => 
                item.title.toLowerCase().includes(searchTerm) || 
                item.excerpt.toLowerCase().includes(searchTerm) ||
                item.categoryName.toLowerCase().includes(searchTerm)
            );
        }

        this.renderKnowledgeItems();
    }

    // 排序知识条目
    sortKnowledgeItems() {
        const sortBy = this.sortSelect.value;

        switch (sortBy) {
            case 'latest':
                this.filteredItems.sort((a, b) => new Date(b.date) - new Date(a.date));
                break;
            case 'popular':
                this.filteredItems.sort((a, b) => b.views - a.views);
                break;
            case 'recommended':
                // 推荐排序：结合多种因素
                this.filteredItems.sort((a, b) => (b.bookmarks * 2 + b.comments) - (a.bookmarks * 2 + a.comments));
                break;
        }

        this.renderKnowledgeItems();
    }

    // 渲染知识条目
    renderKnowledgeItems() {
        if (this.filteredItems.length === 0) {
            this.knowledgeList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3>未找到相关知识</h3>
                    <p>尝试使用其他关键词或分类进行搜索</p>
                </div>
            `;
            return;
        }

        this.knowledgeList.innerHTML = this.filteredItems.map(item => `
            <div class="knowledge-item">
                <div class="knowledge-meta">
                    <span class="category-tag">${item.categoryName}</span>
                    <span class="post-date">${item.date}</span>
                </div>
                <h3 class="knowledge-title">${item.title}</h3>
                <p class="knowledge-excerpt">${item.excerpt}</p>
                <div class="knowledge-stats">
                    <span><i class="fas fa-eye"></i> ${item.views.toLocaleString()}</span>
                    <span><i class="fas fa-bookmark"></i> ${item.bookmarks}</span>
                    <span><i class="fas fa-comment"></i> ${item.comments}</span>
                </div>
            </div>
        `).join('');
    }
}

// 页面加载完成后初始化知识库
document.addEventListener('DOMContentLoaded', () => {
    new KnowledgeBase();
});