// 双因素认证逻辑
class TwoFactorAuth {
  constructor() {
    this.modal = document.getElementById('2fa-modal');
    this.codeInput = document.getElementById('2fa-code');
    this.verifyBtn = document.getElementById('verify-2fa');
    this.cancelBtn = document.getElementById('cancel-2fa');
    this.initEvents();
  }

  // 初始化事件监听
  initEvents() {
    this.verifyBtn.addEventListener('click', () => this.verifyCode());
    this.cancelBtn.addEventListener('click', () => this.hideModal());
    this.codeInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.verifyCode();
    });
  }

  // 显示2FA模态框
  showModal() {
    this.modal.style.display = 'block';
    this.codeInput.value = '';
    this.codeInput.focus();
  }

  // 隐藏2FA模态框
  hideModal() {
    this.modal.style.display = 'none';
  }

  // 验证验证码
  async verifyCode() {
    const code = this.codeInput.value.trim();
    if (!/^\d{6}$/.test(code)) {
      alert('请输入6位数字验证码');
      return;
    }

    try {
      const response = await fetch('/api/auth/verify-2fa', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ code })
      });

      if (response.ok) {
        this.hideModal();
        window.location.href = '/dashboard.html';
      } else {
        const data = await response.json();
        alert(data.message || '验证码验证失败，请重试');
      }
    } catch (error) {
      console.error('2FA验证错误:', error);
      alert('网络错误，请稍后重试');
    }
  }
}

// 初始化2FA模块
document.addEventListener('DOMContentLoaded', () => {
  const twoFactorAuth = new TwoFactorAuth();
  // 暴露给全局，以便auth.js在登录成功后调用
  window.show2FAModal = () => twoFactorAuth.showModal();
});