class CommunitySystem {
    constructor() {
        this.initElements();
        this.bindEvents();
        this.loadDiscussionData();
    }

    initElements() {
        // 获取DOM元素
        this.tabButtons = document.querySelectorAll('.tab-btn');
        this.tabContents = document.querySelectorAll('.tab-content');
        this.discussionCategory = document.getElementById('discussion-category');
        this.discussionSort = document.getElementById('discussion-sort');
        this.discussionList = document.querySelector('.discussion-list');
        this.paginationButtons = document.querySelectorAll('.page-btn');
        this.createPostBtn = document.querySelector('.create-post-btn');

        // 存储讨论数据
        this.discussions = [];
        this.filteredDiscussions = [];
    }

    bindEvents() {
        // 标签页切换事件
        this.tabButtons.forEach(button => {
            button.addEventListener('click', () => this.switchTab(button));
        });

        // 讨论筛选和排序事件
        this.discussionCategory.addEventListener('change', () => this.filterDiscussions());
        this.discussionSort.addEventListener('change', () => this.sortDiscussions());

        // 分页按钮事件
        this.paginationButtons.forEach(button => {
            if (!button.classList.contains('prev') && !button.classList.contains('next')) {
                button.addEventListener('click', () => this.changePage(button));
            }
        });

        // 创建帖子按钮事件
        if (this.createPostBtn) {
            this.createPostBtn.addEventListener('click', () => this.showCreatePostModal());
        }
    }

    // 切换标签页
    switchTab(button) {
        const tabId = button.dataset.tab;

        // 更新按钮状态
        this.tabButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        // 更新内容区域
        this.tabContents.forEach(content => {
            content.classList.remove('active');
            if (content.id === tabId) {
                content.classList.add('active');
            }
        });
    }

    // 加载讨论数据
    loadDiscussionData() {
        // 模拟API请求加载讨论数据
        this.discussions = [
            {
                id: 1,
                title: '2023年网络安全趋势分析与职业发展建议',
                excerpt: '随着AI技术的发展，网络安全领域也面临新的挑战与机遇。本文将分析2023年网络安全行业的发展趋势，并为从业者提供职业发展建议...',
                author: {
                    name: '张安全',
                    avatar: 'assets/images/user1.jpg',
                    badge: '专家'
                },
                category: 'career',
                categoryName: '职业发展',
                postTime: '2小时前',
                commentCount: 28,
                viewCount: 356,
                likeCount: 42
            },
            {
                id: 2,
                title: '请教一个关于SQL注入绕过WAF的问题',
                excerpt: '在测试一个网站时遇到了WAF拦截SQL注入 payload的情况，尝试了多种编码方式仍然无法绕过，请问各位大佬有什么好的方法吗？...',
                author: {
                    name: '李渗透',
                    avatar: 'assets/images/user2.jpg',
                    badge: '新手'
                },
                category: 'tech',
                categoryName: '技术讨论',
                postTime: '昨天 14:32',
                commentCount: 15,
                viewCount: 217,
                likeCount: 8
            },
            {
                id: 3,
                title: '2023年Black Hat大会热点议题汇总',
                excerpt: '今年的Black Hat大会上公布了多项重大安全研究成果，本文汇总了大会的热点议题和值得关注的技术突破...',
                author: {
                    name: '王安全',
                    avatar: 'assets/images/user3.jpg',
                    badge: '资深'
                },
                category: 'news',
                categoryName: '行业动态',
                postTime: '3天前',
                commentCount: 36,
                viewCount: 528,
                likeCount: 74
            },
            {
                id: 4,
                title: '求推荐适合初学者的CTF练习平台',
                excerpt: '刚接触网络安全，想通过CTF比赛提升实战能力，请问各位有哪些适合初学者的CTF练习平台推荐？最好有详细的入门教程...',
                author: {
                    name: '赵小白',
                    avatar: 'assets/images/user4.jpg',
                    badge: '新手'
                },
                category: 'help',
                categoryName: '求助交流',
                postTime: '1周前',
                commentCount: 23,
                viewCount: 312,
                likeCount: 15
            }
        ];

        this.filteredDiscussions = [...this.discussions];
        this.renderDiscussions();
    }

    // 筛选讨论
    filterDiscussions() {
        const category = this.discussionCategory.value;

        if (category === 'all') {
            this.filteredDiscussions = [...this.discussions];
        } else {
            this.filteredDiscussions = this.discussions.filter(discussion => 
                discussion.category === category
            );
        }

        this.renderDiscussions();
    }

    // 排序讨论
    sortDiscussions() {
        const sortBy = this.discussionSort.value;

        switch (sortBy) {
            case 'latest':
                // 按发布时间排序
                this.filteredDiscussions.sort((a, b) => {
                    const dateA = this.parsePostTime(a.postTime);
                    const dateB = this.parsePostTime(b.postTime);
                    return dateB - dateA;
                });
                break;
            case 'hot':
                // 按热度排序（综合评论数和点赞数）
                this.filteredDiscussions.sort((a, b) => 
                    (b.commentCount * 2 + b.likeCount) - (a.commentCount * 2 + a.likeCount)
                );
                break;
            case 'unanswered':
                // 按未回复优先排序
                this.filteredDiscussions.sort((a, b) => a.commentCount - b.commentCount);
                break;
        }

        this.renderDiscussions();
    }

    // 解析发布时间为时间戳
    parsePostTime(timeStr) {
        if (timeStr.includes('小时前')) {
            const hours = parseInt(timeStr);
            return Date.now() - hours * 60 * 60 * 1000;
        } else if (timeStr.includes('天前')) {
            const days = parseInt(timeStr);
            return Date.now() - days * 24 * 60 * 60 * 1000;
        } else if (timeStr.includes('周前')) {
            const weeks = parseInt(timeStr);
            return Date.now() - weeks * 7 * 24 * 60 * 60 * 1000;
        } else {
            return new Date(timeStr).getTime();
        }
    }

    // 渲染讨论列表
    renderDiscussions() {
        if (this.filteredDiscussions.length === 0) {
            this.discussionList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-comments"></i>
                    <h3>未找到相关讨论</h3>
                    <p>尝试选择其他分类或发布新讨论</p>
                </div>
            `;
            return;
        }

        this.discussionList.innerHTML = this.filteredDiscussions.map(discussion => `
            <div class="discussion-item">
                <div class="discussion-author">
                    <img src="${discussion.author.avatar}" alt="${discussion.author.name}">
                    <span class="author-name">${discussion.author.name}</span>
                    <span class="author-badge">${discussion.author.badge}</span>
                </div>
                <div class="discussion-content">
                    <h3 class="discussion-title"><a href="#">${discussion.title}</a></h3>
                    <p class="discussion-excerpt">${discussion.excerpt}</p>
                    <div class="discussion-meta">
                        <span class="category-tag">${discussion.categoryName}</span>
                        <span class="post-time">${discussion.postTime}</span>
                        <span class="comment-count"><i class="fas fa-comment"></i> ${discussion.commentCount}</span>
                        <span class="view-count"><i class="fas fa-eye"></i> ${discussion.viewCount}</span>
                        <span class="like-count"><i class="fas fa-thumbs-up"></i> ${discussion.likeCount}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    // 切换分页
    changePage(button) {
        this.paginationButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        // 在实际应用中，这里会加载对应页的讨论数据
    }

    // 显示创建帖子模态框
    showCreatePostModal() {
        // 在实际应用中，这里会显示创建帖子的模态框
        alert('创建新讨论功能即将上线，敬请期待！');
    }
}

// 页面加载完成后初始化社区系统
document.addEventListener('DOMContentLoaded', () => {
    new CommunitySystem();
});