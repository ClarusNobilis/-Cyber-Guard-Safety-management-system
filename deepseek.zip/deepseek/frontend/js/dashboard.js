document.addEventListener('DOMContentLoaded', function() {
    // 检查用户是否已登录
    if (!Auth.isLoggedIn()) {
        window.location.href = 'login.html';
        return;
    }

    // 初始化控制台
    initDashboard();
});

// 初始化控制台
function initDashboard() {
    // 加载用户信息
    loadUserInfo();
    
    // 显示最近登录时间
    displayLastLogin();
    
    // 初始化图表
    initCharts();
    
    // 初始化事件监听器
    initEventListeners();
    
    // 加载统计数据
    loadStats();
}

// 加载用户信息
function loadUserInfo() {
    const user = Auth.getCurrentUser();
    if (user) {
        // 显示用户名
        const userProfileElement = document.querySelector('[data-user-profile]');
        if (userProfileElement) {
            userProfileElement.textContent = `欢迎，${user.username}`;
        }
        
        // 设置登出按钮事件
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function() {
                Auth.logout();
                window.location.href = 'index.html';
            });
        }
    }
}

// 显示最近登录时间
function displayLastLogin() {
    const lastLoginElement = document.getElementById('last-login');
    if (lastLoginElement) {
        const lastLogin = localStorage.getItem('last_login') || new Date().toLocaleString();
        lastLoginElement.textContent = lastLogin;
        
        // 更新最近登录时间
        localStorage.setItem('last_login', new Date().toLocaleString());
    }
}

// 初始化图表
function initCharts() {
    const ctx = document.getElementById('contentTrendChart');
    if (!ctx) return;
    
    // 默认显示周数据
    const weekData = {
        labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
        datasets: [{
            label: '文章访问量',
            data: [65, 59, 80, 81, 56, 55, 40],
            borderColor: '#1a73e8',
            backgroundColor: 'rgba(26, 115, 232, 0.1)',
            tension: 0.4,
            fill: true
        }, {
            label: '工具下载量',
            data: [28, 48, 40, 19, 86, 27, 90],
            borderColor: '#00bcd4',
            backgroundColor: 'rgba(0, 188, 212, 0.1)',
            tension: 0.4,
            fill: true
        }]
    };
    
    const monthData = {
        labels: Array.from({length: 30}, (_, i) => i + 1),
        datasets: [{
            label: '文章访问量',
            data: Array.from({length: 30}, () => Math.floor(Math.random() * 100) + 20),
            borderColor: '#1a73e8',
            backgroundColor: 'rgba(26, 115, 232, 0.1)',
            tension: 0.4,
            fill: true
        }, {
            label: '工具下载量',
            data: Array.from({length: 30}, () => Math.floor(Math.random() * 100) + 10),
            borderColor: '#00bcd4',
            backgroundColor: 'rgba(0, 188, 212, 0.1)',
            tension: 0.4,
            fill: true
        }]
    };
    
    const yearData = {
        labels: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
        datasets: [{
            label: '文章访问量',
            data: [1200, 1900, 3000, 5000, 2000, 3000, 7000, 6000, 4000, 5000, 8000, 9000],
            borderColor: '#1a73e8',
            backgroundColor: 'rgba(26, 115, 232, 0.1)',
            tension: 0.4,
            fill: true
        }, {
            label: '工具下载量',
            data: [900, 1200, 1900, 3000, 1500, 2000, 3500, 3000, 2500, 4000, 6000, 7500],
            borderColor: '#00bcd4',
            backgroundColor: 'rgba(0, 188, 212, 0.1)',
            tension: 0.4,
            fill: true
        }]
    };
    
    // 创建图表
    window.contentChart = new Chart(ctx, {
        type: 'line',
        data: weekData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: '#f5f5f5'
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b0b0b0'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b0b0b0'
                    }
                }
            }
        }
    });
    
    // 处理图表过滤器点击
    const chartFilters = document.querySelectorAll('.chart-filters button');
    chartFilters.forEach(button => {
        button.addEventListener('click', function() {
            // 更新活动状态
            chartFilters.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // 更新图表数据
            const period = this.getAttribute('data-period');
            let chartData;
            
            switch(period) {
                case 'week':
                    chartData = weekData;
                    break;
                case 'month':
                    chartData = monthData;
                    break;
                case 'year':
                    chartData = yearData;
                    break;
                default:
                    chartData = weekData;
            }
            
            window.contentChart.data = chartData;
            window.contentChart.update();
        });
    });
}

// 初始化事件监听器
function initEventListeners() {
    // 两步验证切换
    const toggle2fa = document.querySelector('.toggle-2fa');
    if (toggle2fa) {
        toggle2fa.addEventListener('click', function() {
            if (this.classList.contains('enabled')) {
                this.classList.remove('enabled');
                this.textContent = '未启用';
            } else {
                this.classList.add('enabled');
                this.textContent = '已启用';
                
                // 显示成功消息
                showNotification('两步验证已成功启用', 'success');
            }
        });
    }
    
    // 密码修改点击
    const passwordChange = document.querySelector('.security-settings li:nth-child(3)');
    if (passwordChange) {
        passwordChange.style.cursor = 'pointer';
        passwordChange.addEventListener('click', function() {
            // 这里可以添加打开密码修改模态框的逻辑
            showPasswordChangeModal();
        });
    }
    
    // 登录设备管理点击
    const deviceManagement = document.querySelector('.security-settings li:nth-child(2)');
    if (deviceManagement) {
        deviceManagement.style.cursor = 'pointer';
        deviceManagement.addEventListener('click', function() {
            // 这里可以添加打开设备管理模态框的逻辑
            showDeviceManagementModal();
        });
    }
}

// 加载统计数据
function loadStats() {
    // 这里可以从API获取真实数据
    // 模拟数据加载
    setTimeout(() => {
        document.getElementById('article-count').textContent = '12';
        document.getElementById('tool-downloads').textContent = '2.4k';
    }, 500);
}

// 显示密码修改模态框
function showPasswordChangeModal() {
    // 创建模态框
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>修改密码</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="current-password">当前密码</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="current-password" class="form-control" placeholder="请输入当前密码">
                    </div>
                </div>
                <div class="form-group">
                    <label for="new-password">新密码</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="new-password" class="form-control" placeholder="请输入新密码">
                    </div>
                    <div class="password-strength">
                        <div class="strength-meter" id="password-strength"></div>
                    </div>
                    <div class="strength-text" id="password-strength-text">密码强度：弱</div>
                </div>
                <div class="form-group">
                    <label for="confirm-password">确认新密码</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="confirm-password" class="form-control" placeholder="请再次输入新密码">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline modal-cancel">取消</button>
                <button class="btn btn-primary" id="change-password-btn">确认修改</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 显示模态框
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
    
    // 关闭模态框
    const closeModal = modal.querySelector('.close-modal');
    const cancelBtn = modal.querySelector('.modal-cancel');
    
    closeModal.addEventListener('click', () => {
        modal.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(modal);
        }, 300);
    });
    
    cancelBtn.addEventListener('click', () => {
        modal.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(modal);
        }, 300);
    });
    
    // 密码强度检测
    const passwordInput = document.getElementById('new-password');
    const strengthMeter = document.getElementById('password-strength');
    const strengthText = document.getElementById('password-strength-text');
    
    passwordInput.addEventListener('input', function() {
        const password = this.value;
        let strength = 0;
        
        // 长度检测
        if (password.length >= 8) strength += 1;
        
        // 包含小写字母
        if (/[a-z]/.test(password)) strength += 1;
        
        // 包含大写字母
        if (/[A-Z]/.test(password)) strength += 1;
        
        // 包含数字
        if (/[0-9]/.test(password)) strength += 1;
        
        // 包含特殊字符
        if (/[^A-Za-z0-9]/.test(password)) strength += 1;
        
        // 更新UI
        strengthMeter.className = 'strength-meter';
        
        if (password.length === 0) {
            strengthText.textContent = '密码强度：';
            return;
        }
        
        if (strength <= 2) {
            strengthMeter.classList.add('strength-weak');
            strengthText.textContent = '密码强度：弱';
        } else if (strength <= 4) {
            strengthMeter.classList.add('strength-medium');
            strengthText.textContent = '密码强度：中等';
        } else {
            strengthMeter.classList.add('strength-strong');
            strengthText.textContent = '密码强度：强';
        }
    });
    
    // 处理密码修改
    const changePasswordBtn = document.getElementById('change-password-btn');
    changePasswordBtn.addEventListener('click', function() {
        const currentPassword = document.getElementById('current-password').value;
        const newPassword = document.getElementById('new-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        
        // 验证输入
        if (!currentPassword || !newPassword || !confirmPassword) {
            showNotification('请填写所有密码字段', 'error');
            return;
        }
        
        if (newPassword !== confirmPassword) {
            showNotification('两次输入的新密码不一致', 'error');
            return;
        }
        
        // 验证密码强度
        if (!isStrongPassword(newPassword)) {
            showNotification('新密码强度不足，请确保密码至少8个字符，并包含大小写字母、数字和特殊字符', 'error');
            return;
        }
        
        // 这里可以添加API调用来更改密码
        // 模拟API调用
        setTimeout(() => {
            showNotification('密码修改成功', 'success');
            modal.style.opacity = '0';
            setTimeout(() => {
                document.body.removeChild(modal);
            }, 300);
        }, 1000);
    });
}

// 显示设备管理模态框
function showDeviceManagementModal() {
    // 创建模态框
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>登录设备管理</h3>
                <span class="close-modal">&times;</span>
            </div>
            <div class="modal-body">
                <div class="device-list">
                    <div class="device-item">
                        <div class="device-info">
                            <h4>Windows PC - Chrome</h4>
                            <p>当前设备 · 上次登录: 刚刚</p>
                            <p>IP: 192.168.1.1 · 位置: 北京</p>
                        </div>
                        <div class="device-actions">
                            <span class="device-status current">当前</span>
                        </div>
                    </div>
                    <div class="device-item">
                        <div class="device-info">
                            <h4>iPhone 13 - Safari</h4>
                            <p>上次登录: 昨天 15:30</p>
                            <p>IP: 192.168.1.2 · 位置: 上海</p>
                        </div>
                        <div class="device-actions">
                            <button class="btn btn-danger btn-sm">移除</button>
                        </div>
                    </div>
                    <div class="device-item">
                        <div class="device-info">
                            <h4>MacBook Pro - Firefox</h4>
                            <p>上次登录: 2023-05-15 09:45</p>
                            <p>IP: 192.168.1.3 · 位置: 广州</p>
                        </div>
                        <div class="device-actions">
                            <button class="btn btn-danger btn-sm">移除</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline modal-cancel">关闭</button>
                <button class="btn btn-danger" id="logout-all-devices">登出所有其他设备</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // 显示模态框
    setTimeout(() => {
        modal.style.opacity = '1';
    }, 10);
    
    // 关闭模态框
    const closeModal = modal.querySelector('.close-modal');
    const cancelBtn = modal.querySelector('.modal-cancel');
    
    closeModal.addEventListener('click', () => {
        modal.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(modal);
        }, 300);
    });
    
    cancelBtn.addEventListener('click', () => {
        modal.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(modal);
        }, 300);
    });
    
    // 处理移除设备按钮
    const removeButtons = modal.querySelectorAll('.btn-danger.btn-sm');
    removeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const deviceItem = this.closest('.device-item');
            deviceItem.style.opacity = '0.5';
            this.textContent = '移除中...';
            this.disabled = true;
            
            // 模拟API调用
            setTimeout(() => {
                deviceItem.style.display = 'none';
                showNotification('设备已成功移除', 'success');
            }, 1000);
        });
    });
    
    // 处理登出所有其他设备按钮
    const logoutAllBtn = document.getElementById('logout-all-devices');
    logoutAllBtn.addEventListener('click', function() {
        this.textContent = '处理中...';
        this.disabled = true;
        
        // 模拟API调用
        setTimeout(() => {
            const deviceItems = modal.querySelectorAll('.device-item:not(:first-child)');
            deviceItems.forEach(item => {
                item.style.display = 'none';
            });
            
            this.textContent = '已完成';
            showNotification('已成功登出所有其他设备', 'success');
            
            setTimeout(() => {
                modal.style.opacity = '0';
                setTimeout(() => {
                    document.body.removeChild(modal);
                }, 300);
            }, 1000);
        }, 1500);
    });
}

// 显示通知
function showNotification(message, type = 'info') {
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // 设置图标
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    
    notification.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
    `;
    
    // 添加到页面
    document.body.appendChild(notification);
    
    // 显示通知
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // 自动关闭
    setTimeout(() => {
        notification.style.transform = 'translateX(120%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 5000);
}

// 验证密码强度
function isStrongPassword(password) {
    let strength = 0;
    
    // 长度检测
    if (password.length >= 8) strength += 1;
    
    // 包含小写字母
    if (/[a-z]/.test(password)) strength += 1;
    
    // 包含大写字母
    if (/[A-Z]/.test(password)) strength += 1;
    
    // 包含数字
    if (/[0-9]/.test(password)) strength += 1;
    
    // 包含特殊字符
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    // 返回密码是否足够强（至少需要4个条件）
    return strength >= 4;
}